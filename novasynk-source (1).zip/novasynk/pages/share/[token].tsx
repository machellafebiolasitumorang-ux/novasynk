import { useEffect, useState } from 'react'
import { useRouter } from 'next/router'
import { supabase } from '../../lib/supabase'
import Head from 'next/head'

export default function SharePage() {
  const router = useRouter()
  const { token } = router.query
  const [file, setFile] = useState<any>(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(true)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    if (!token) return
    loadFile()
  }, [token])

  async function loadFile() {
    const { data, error } = await supabase
      .from('files')
      .select('*, profiles:uploaded_by(name)')
      .eq('share_token', token)
      .single()

    if (error || !data) {
      setError('File tidak ditemukan atau link tidak valid.')
    } else if (data.access === 'private') {
      setError('File ini bersifat private dan tidak dapat diakses.')
    } else {
      setFile(data)
    }
    setLoading(false)
  }

  async function copyLink() {
    await navigator.clipboard.writeText(window.location.href)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  function formatSize(bytes: number) {
    if (!bytes) return '—'
    if (bytes < 1024) return bytes + ' B'
    if (bytes < 1024*1024) return (bytes/1024).toFixed(0) + ' KB'
    return (bytes/1024/1024).toFixed(1) + ' MB'
  }

  function isImage(file: any) {
    return file.mime_type?.includes('image') || ['jpg','jpeg','png','webp'].some((e:string) => file.original_name?.toLowerCase().endsWith(e))
  }
  function isPDF(file: any) {
    return file.mime_type?.includes('pdf') || file.original_name?.toLowerCase().endsWith('.pdf')
  }

  if (loading) return (
    <div style={{ minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:'#0c0c10', color:'#a594ff', fontFamily:'sans-serif' }}>
      Memuat file...
    </div>
  )

  if (error) return (
    <div style={{ minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:'#0c0c10', fontFamily:'sans-serif', padding:20 }}>
      <div style={{ textAlign:'center' }}>
        <i className="ti ti-file-off" style={{ fontSize:48, color:'#5c5a7a', display:'block', marginBottom:16 }}></i>
        <div style={{ fontSize:16, color:'#f0efff', marginBottom:8 }}>{error}</div>
        <a href="/" style={{ color:'#a594ff', fontSize:13 }}>← Kembali ke NOVASYNK</a>
      </div>
    </div>
  )

  return (
    <>
      <Head>
        <title>{file.original_name} — NOVASYNK</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css" />
        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600&family=Syne:wght@700;800&display=swap" rel="stylesheet" />
      </Head>
      <div style={{ minHeight:'100vh', background:'#0c0c10', fontFamily:'DM Sans,sans-serif', color:'#f0efff' }}>
        {/* Header */}
        <div style={{ padding:'16px 24px', borderBottom:'1px solid rgba(255,255,255,0.07)', display:'flex', alignItems:'center', gap:14, background:'#13131a' }}>
          <div style={{ width:36, height:36, borderRadius:10, background:'linear-gradient(135deg,#7c6cff,#a594ff)', display:'flex', alignItems:'center', justifyContent:'center' }}>
            <span style={{ fontFamily:'Syne,sans-serif', fontWeight:800, fontSize:14, color:'#fff' }}>NS</span>
          </div>
          <div>
            <div style={{ fontFamily:'Syne,sans-serif', fontWeight:700, fontSize:14, color:'#f0efff' }}>NOVASYNK</div>
            <div style={{ fontSize:10, color:'#5c5a7a' }}>Shared File</div>
          </div>
          <div style={{ marginLeft:'auto', display:'flex', gap:10, alignItems:'center' }}>
            <span style={{ fontSize:11, color: file.access === 'public' ? '#2dd6a0' : '#5baeff', background: file.access === 'public' ? 'rgba(45,214,160,0.1)' : 'rgba(91,174,255,0.1)', padding:'3px 9px', borderRadius:8, border:`1px solid ${file.access === 'public' ? 'rgba(45,214,160,.25)' : 'rgba(91,174,255,.25)'}` }}>
              {file.access === 'public' ? '🌐 Public' : '👥 Team'}
            </span>
            <a href="/" style={{ fontSize:12, color:'#a594ff' }}>Buka NOVASYNK →</a>
          </div>
        </div>

        <div style={{ maxWidth:900, margin:'0 auto', padding:'24px 20px' }}>
          {/* File info */}
          <div style={{ background:'#13131a', border:'1px solid rgba(255,255,255,0.07)', borderRadius:14, padding:20, marginBottom:20 }}>
            <div style={{ display:'flex', alignItems:'flex-start', gap:14, flexWrap:'wrap' }}>
              <div style={{ flex:1, minWidth:200 }}>
                <div style={{ fontFamily:'Syne,sans-serif', fontSize:18, fontWeight:700, color:'#f0efff', marginBottom:6, wordBreak:'break-word' }}>{file.original_name}</div>
                <div style={{ display:'flex', gap:12, flexWrap:'wrap', fontSize:12, color:'#5c5a7a' }}>
                  <span><i className="ti ti-user" style={{ marginRight:4 }}></i>{file.profiles?.name || '—'}</span>
                  <span><i className="ti ti-database" style={{ marginRight:4 }}></i>{formatSize(file.size_bytes)}</span>
                  <span><i className="ti ti-folder" style={{ marginRight:4 }}></i>{file.folder}</span>
                  <span><i className="ti ti-calendar" style={{ marginRight:4 }}></i>{new Date(file.created_at).toLocaleDateString('id-ID',{day:'numeric',month:'long',year:'numeric'})}</span>
                </div>
              </div>

              {/* Action buttons */}
              <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
                <a href={file.public_url} target="_blank" rel="noopener noreferrer"
                  style={{ display:'inline-flex', alignItems:'center', gap:6, padding:'8px 16px', background:'#7c6cff', border:'none', borderRadius:8, color:'#fff', fontSize:13, fontWeight:600, textDecoration:'none', cursor:'pointer' }}>
                  <i className="ti ti-external-link"></i> Open File
                </a>
                <a href={file.public_url} download={file.original_name}
                  style={{ display:'inline-flex', alignItems:'center', gap:6, padding:'8px 16px', background:'transparent', border:'1px solid rgba(255,255,255,0.13)', borderRadius:8, color:'#f0efff', fontSize:13, textDecoration:'none', cursor:'pointer' }}>
                  <i className="ti ti-download"></i> Download
                </a>
                <button onClick={copyLink}
                  style={{ display:'inline-flex', alignItems:'center', gap:6, padding:'8px 16px', background: copied ? 'rgba(45,214,160,0.15)' : 'transparent', border:`1px solid ${copied ? 'rgba(45,214,160,.35)' : 'rgba(255,255,255,0.13)'}`, borderRadius:8, color: copied ? '#2dd6a0' : '#f0efff', fontSize:13, cursor:'pointer', transition:'all .2s' }}>
                  <i className={`ti ${copied ? 'ti-check' : 'ti-link'}`}></i> {copied ? 'Link Disalin!' : 'Copy Link'}
                </button>
                <button onClick={async () => {
                  if (navigator.share) {
                    navigator.share({ title: file.original_name, url: window.location.href })
                  } else { copyLink() }
                }}
                  style={{ display:'inline-flex', alignItems:'center', gap:6, padding:'8px 16px', background:'transparent', border:'1px solid rgba(255,255,255,0.13)', borderRadius:8, color:'#f0efff', fontSize:13, cursor:'pointer' }}>
                  <i className="ti ti-share"></i> Share Link
                </button>
              </div>
            </div>
          </div>

          {/* Preview */}
          <div style={{ background:'#13131a', border:'1px solid rgba(255,255,255,0.07)', borderRadius:14, overflow:'hidden' }}>
            <div style={{ padding:'12px 16px', borderBottom:'1px solid rgba(255,255,255,0.07)', fontSize:13, fontWeight:500, color:'#9896b8' }}>
              Preview
            </div>
            <div style={{ minHeight:400 }}>
              {isImage(file) ? (
                <div style={{ display:'flex', justifyContent:'center', alignItems:'center', padding:24, minHeight:400 }}>
                  <img src={file.public_url} alt={file.original_name} style={{ maxWidth:'100%', maxHeight:'70vh', borderRadius:8 }} />
                </div>
              ) : isPDF(file) ? (
                <iframe src={file.public_url} style={{ width:'100%', height:'70vh', border:'none', display:'block' }}></iframe>
              ) : (
                <div style={{ textAlign:'center', padding:60, color:'#5c5a7a' }}>
                  <i className="ti ti-file" style={{ fontSize:52, display:'block', marginBottom:14, color:'#22222f' }}></i>
                  <div style={{ fontSize:14, marginBottom:8, color:'#9896b8' }}>Preview tidak tersedia untuk format ini</div>
                  <div style={{ fontSize:12, marginBottom:20 }}>Format: {file.mime_type || file.original_name?.split('.').pop()?.toUpperCase()}</div>
                  <a href={file.public_url} target="_blank" rel="noopener" style={{ display:'inline-flex', alignItems:'center', gap:6, padding:'8px 16px', background:'#7c6cff', borderRadius:8, color:'#fff', fontSize:13, fontWeight:600, textDecoration:'none' }}>
                    <i className="ti ti-external-link"></i> Buka di tab baru
                  </a>
                </div>
              )}
            </div>
          </div>

          <div style={{ textAlign:'center', marginTop:20, fontSize:12, color:'#5c5a7a' }}>
            Dibagikan via <strong style={{ color:'#a594ff' }}>NOVASYNK</strong> · Sistem Manajemen Organisasi Tim
          </div>
        </div>
      </div>
    </>
  )
}
