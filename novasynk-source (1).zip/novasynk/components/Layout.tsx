import { useRouter } from 'next/router'
import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import Link from 'next/link'

const NAV = [
  { id: 'dashboard', label: 'Dashboard', icon: 'ti-layout-dashboard', href: '/' },
  { id: 'tasks', label: 'Tugas', icon: 'ti-checklist', href: '/tasks' },
  { id: 'schedule', label: 'Jadwal', icon: 'ti-calendar', href: '/schedule' },
  { id: 'chat', label: 'Chat Tim', icon: 'ti-message-2', href: '/chat' },
  { id: 'docs', label: 'Dokumen', icon: 'ti-folder', href: '/docs' },
  { id: 'progress', label: 'Progres', icon: 'ti-chart-bar', href: '/progress' },
  { id: 'members', label: 'Anggota', icon: 'ti-users', href: '/members' },
]

export default function Layout({ children, title }: { children: React.ReactNode, title?: string }) {
  const router = useRouter()
  const [profile, setProfile] = useState<any>(null)
  const [unreadMsg, setUnreadMsg] = useState(0)

  useEffect(() => {
    supabase.auth.getUser().then(async ({ data: { user } }) => {
      if (user) {
        const { data } = await supabase.from('profiles').select('*').eq('id', user.id).single()
        setProfile(data)
      }
    })
    // Count unread messages (simplified)
    setUnreadMsg(Math.floor(Math.random() * 5))
  }, [])

  async function handleLogout() {
    await supabase.auth.signOut()
    router.push('/login')
  }

  const active = router.pathname

  return (
    <div style={{ display:'flex', height:'100vh', overflow:'hidden' }}>
      {/* Sidebar */}
      <div style={{ width:220, background:'#13131a', borderRight:'1px solid rgba(255,255,255,0.07)', display:'flex', flexDirection:'column', flexShrink:0 }}>
        {/* Logo */}
        <div style={{ padding:'18px 16px', borderBottom:'1px solid rgba(255,255,255,0.07)', display:'flex', alignItems:'center', gap:10 }}>
          <div style={{ width:34, height:34, borderRadius:9, background:'linear-gradient(135deg,#7c6cff,#a594ff)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
            <span style={{ fontFamily:'Syne,sans-serif', fontWeight:800, fontSize:13, color:'#fff' }}>NS</span>
          </div>
          <div>
            <div style={{ fontFamily:'Syne,sans-serif', fontWeight:700, fontSize:14, color:'#f0efff' }}>NOVASYNK</div>
            <div style={{ fontSize:10, color:'#5c5a7a', marginTop:1 }}>Divisi Produk</div>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ flex:1, padding:'8px 0', overflowY:'auto' }}>
          <div style={{ padding:'10px 16px 4px', fontSize:10, color:'#5c5a7a', letterSpacing:'.08em', textTransform:'uppercase', fontWeight:600 }}>Utama</div>
          {NAV.slice(0,4).map(item => (
            <Link key={item.id} href={item.href} style={{ display:'flex', alignItems:'center', gap:9, padding:'8px 14px', margin:'1px 8px', fontSize:13, color: active === item.href ? '#a594ff' : '#9896b8', cursor:'pointer', borderRadius:8, textDecoration:'none', background: active === item.href ? 'rgba(124,108,255,0.12)' : 'transparent', border: active === item.href ? '1px solid rgba(124,108,255,0.35)' : '1px solid transparent', transition:'all .15s' }}>
              <i className={`ti ${item.icon}`} style={{ fontSize:16 }}></i>
              {item.label}
              {item.id === 'chat' && unreadMsg > 0 && (
                <span style={{ marginLeft:'auto', background:'#7c6cff', color:'#fff', fontSize:9, padding:'1px 6px', borderRadius:8, fontWeight:700 }}>{unreadMsg}</span>
              )}
            </Link>
          ))}

          <div style={{ padding:'10px 16px 4px', fontSize:10, color:'#5c5a7a', letterSpacing:'.08em', textTransform:'uppercase', fontWeight:600, marginTop:4 }}>Organisasi</div>
          {NAV.slice(4).map(item => (
            <Link key={item.id} href={item.href} style={{ display:'flex', alignItems:'center', gap:9, padding:'8px 14px', margin:'1px 8px', fontSize:13, color: active === item.href ? '#a594ff' : '#9896b8', cursor:'pointer', borderRadius:8, textDecoration:'none', background: active === item.href ? 'rgba(124,108,255,0.12)' : 'transparent', border: active === item.href ? '1px solid rgba(124,108,255,0.35)' : '1px solid transparent', transition:'all .15s' }}>
              <i className={`ti ${item.icon}`} style={{ fontSize:16 }}></i>
              {item.label}
            </Link>
          ))}
        </nav>

        {/* User */}
        <div style={{ padding:12, borderTop:'1px solid rgba(255,255,255,0.07)' }}>
          <div style={{ display:'flex', alignItems:'center', gap:9, padding:'8px 10px', borderRadius:8, cursor:'pointer' }}
            onClick={handleLogout} title="Klik untuk logout">
            <div style={{ width:30, height:30, borderRadius:'50%', background:'linear-gradient(135deg,#a594ff,#7c6cff)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:11, fontWeight:700, color:'#fff', flexShrink:0 }}>
              {profile?.name?.slice(0,2).toUpperCase() || 'U'}
            </div>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ fontSize:12, fontWeight:500, color:'#f0efff', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{profile?.name || 'User'}</div>
              <div style={{ fontSize:10, color:'#5c5a7a' }}>{profile?.role === 'admin' ? 'Admin' : 'Member'}</div>
            </div>
            <i className="ti ti-logout" style={{ fontSize:15, color:'#5c5a7a' }}></i>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div style={{ flex:1, display:'flex', flexDirection:'column', overflow:'hidden', background:'#0c0c10' }}>
        {title && (
          <div style={{ padding:'13px 24px', borderBottom:'1px solid rgba(255,255,255,0.07)', flexShrink:0 }}>
            <h1 style={{ fontFamily:'Syne,sans-serif', fontSize:16, fontWeight:700, color:'#f0efff', letterSpacing:'-.3px' }}>{title}</h1>
          </div>
        )}
        <div style={{ flex:1, overflowY:'auto', padding:'20px 24px' }}>
          {children}
        </div>
      </div>
    </div>
  )
}
