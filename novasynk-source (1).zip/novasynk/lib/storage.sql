-- ============================================
-- STORAGE SETUP
-- Jalankan di Supabase SQL Editor setelah schema.sql
-- ============================================

-- Buat bucket "documents" untuk file storage
insert into storage.buckets (id, name, public)
values ('documents', 'documents', true);

-- Policy: siapa saja bisa baca file public
create policy "Public files are viewable by everyone"
  on storage.objects for select
  using ( bucket_id = 'documents' );

-- Policy: user yang login bisa upload
create policy "Authenticated users can upload files"
  on storage.objects for insert
  with check ( bucket_id = 'documents' AND auth.role() = 'authenticated' );

-- Policy: user bisa hapus file miliknya
create policy "Users can delete own files"
  on storage.objects for delete
  using ( bucket_id = 'documents' AND auth.uid()::text = (storage.foldername(name))[1] );

-- Policy: user bisa update file miliknya  
create policy "Users can update own files"
  on storage.objects for update
  using ( bucket_id = 'documents' AND auth.uid()::text = (storage.foldername(name))[1] );
