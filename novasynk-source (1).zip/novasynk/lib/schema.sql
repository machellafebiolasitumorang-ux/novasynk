-- ============================================
-- NOVASYNK DATABASE SCHEMA
-- Jalankan di Supabase SQL Editor
-- ============================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ============================================
-- USERS TABLE (extends Supabase auth.users)
-- ============================================
create table public.profiles (
  id uuid references auth.users(id) on delete cascade primary key,
  name text not null,
  email text not null unique,
  avatar_url text,
  role text default 'member' check (role in ('admin','member')),
  is_active boolean default true,
  last_seen timestamp with time zone,
  created_at timestamp with time zone default now()
);

-- ============================================
-- TASKS TABLE
-- ============================================
create table public.tasks (
  id uuid default uuid_generate_v4() primary key,
  title text not null,
  description text,
  status text default 'todo' check (status in ('todo','wip','review','done')),
  priority text default 'mid' check (priority in ('high','mid','low')),
  assigned_to uuid references public.profiles(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  deadline date,
  progress integer default 0 check (progress >= 0 and progress <= 100),
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- ============================================
-- FILES TABLE
-- ============================================
create table public.files (
  id uuid default uuid_generate_v4() primary key,
  name text not null,
  original_name text not null,
  storage_path text not null,
  public_url text,
  mime_type text,
  size_bytes bigint,
  folder text default 'Umum',
  access text default 'team' check (access in ('public','team','private')),
  share_token text unique default encode(gen_random_bytes(16), 'hex'),
  uploaded_by uuid references public.profiles(id) on delete set null,
  version integer default 1,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- ============================================
-- FILE VERSIONS TABLE
-- ============================================
create table public.file_versions (
  id uuid default uuid_generate_v4() primary key,
  file_id uuid references public.files(id) on delete cascade,
  version integer not null,
  storage_path text not null,
  size_bytes bigint,
  uploaded_by uuid references public.profiles(id) on delete set null,
  note text,
  created_at timestamp with time zone default now()
);

-- ============================================
-- MESSAGES TABLE
-- ============================================
create table public.messages (
  id uuid default uuid_generate_v4() primary key,
  channel text not null default 'umum',
  sender_id uuid references public.profiles(id) on delete cascade,
  content text not null,
  file_url text,
  file_name text,
  created_at timestamp with time zone default now()
);

-- ============================================
-- SCHEDULES TABLE
-- ============================================
create table public.schedules (
  id uuid default uuid_generate_v4() primary key,
  title text not null,
  description text,
  event_at timestamp with time zone not null,
  event_end timestamp with time zone,
  color text default '#7c6cff',
  participants uuid[] default '{}',
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamp with time zone default now()
);

-- ============================================
-- ACTIVITY LOG TABLE
-- ============================================
create table public.activity_logs (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.profiles(id) on delete set null,
  action text not null,
  entity_type text,
  entity_id uuid,
  detail text,
  created_at timestamp with time zone default now()
);

-- ============================================
-- INDEXES
-- ============================================
create index idx_tasks_status on public.tasks(status);
create index idx_tasks_assigned_to on public.tasks(assigned_to);
create index idx_files_folder on public.files(folder);
create index idx_files_share_token on public.files(share_token);
create index idx_messages_channel on public.messages(channel);
create index idx_messages_created_at on public.messages(created_at desc);
create index idx_activity_logs_created_at on public.activity_logs(created_at desc);

-- ============================================
-- ROW LEVEL SECURITY
-- ============================================
alter table public.profiles enable row level security;
alter table public.tasks enable row level security;
alter table public.files enable row level security;
alter table public.file_versions enable row level security;
alter table public.messages enable row level security;
alter table public.schedules enable row level security;
alter table public.activity_logs enable row level security;

-- Profiles: bisa dilihat semua user yang login
create policy "Profiles viewable by authenticated users" on public.profiles
  for select using (auth.role() = 'authenticated');

create policy "Users can update own profile" on public.profiles
  for update using (auth.uid() = id);

create policy "Users can insert own profile" on public.profiles
  for insert with check (auth.uid() = id);

-- Tasks: semua user login bisa baca & tulis
create policy "Tasks: read by authenticated" on public.tasks
  for select using (auth.role() = 'authenticated');

create policy "Tasks: insert by authenticated" on public.tasks
  for insert with check (auth.role() = 'authenticated');

create policy "Tasks: update by authenticated" on public.tasks
  for update using (auth.role() = 'authenticated');

create policy "Tasks: delete by owner or admin" on public.tasks
  for delete using (
    auth.uid() = created_by or 
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

-- Files: baca berdasarkan access level
create policy "Files: public files viewable by anyone" on public.files
  for select using (access = 'public' or auth.role() = 'authenticated');

create policy "Files: insert by authenticated" on public.files
  for insert with check (auth.role() = 'authenticated');

create policy "Files: update by owner or admin" on public.files
  for update using (
    auth.uid() = uploaded_by or
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

create policy "Files: delete by owner or admin" on public.files
  for delete using (
    auth.uid() = uploaded_by or
    exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
  );

-- File versions
create policy "File versions: read by authenticated" on public.file_versions
  for select using (auth.role() = 'authenticated');

create policy "File versions: insert by authenticated" on public.file_versions
  for insert with check (auth.role() = 'authenticated');

-- Messages: semua authenticated
create policy "Messages: read by authenticated" on public.messages
  for select using (auth.role() = 'authenticated');

create policy "Messages: insert by authenticated" on public.messages
  for insert with check (auth.role() = 'authenticated');

-- Schedules
create policy "Schedules: read by authenticated" on public.schedules
  for select using (auth.role() = 'authenticated');

create policy "Schedules: insert by authenticated" on public.schedules
  for insert with check (auth.role() = 'authenticated');

create policy "Schedules: update by creator" on public.schedules
  for update using (auth.uid() = created_by);

-- Activity logs
create policy "Activity: read by authenticated" on public.activity_logs
  for select using (auth.role() = 'authenticated');

create policy "Activity: insert by authenticated" on public.activity_logs
  for insert with check (auth.role() = 'authenticated');

-- ============================================
-- REALTIME (untuk live chat & notifikasi)
-- ============================================
alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.tasks;
alter publication supabase_realtime add table public.activity_logs;

-- ============================================
-- SEED: 5 User Accounts
-- Setelah schema ini dijalankan, daftarkan 5 user
-- melalui Supabase Auth > Users > Add User:
-- machella@novasynk.app  / Nova@2026
-- desi@novasynk.app      / Nova@2026
-- dhisry@novasynk.app    / Nova@2026
-- maydela@novasynk.app   / Nova@2026
-- kholil@novasynk.app    / Nova@2026
-- Kemudian jalankan INSERT berikut setelah user dibuat:
-- ============================================

-- (Ganti UUID dengan UUID asli dari Supabase Auth > Users)
-- insert into public.profiles (id, name, email, role) values
--   ('UUID-MACHELLA', 'Machella', 'machella@novasynk.app', 'admin'),
--   ('UUID-DESI',     'Desi',     'desi@novasynk.app',     'member'),
--   ('UUID-DHISRY',   'Dhisry',   'dhisry@novasynk.app',   'member'),
--   ('UUID-MAYDELA',  'Maydela',  'maydela@novasynk.app',  'member'),
--   ('UUID-KHOLIL',   'Kholil',   'kholil@novasynk.app',   'member');
